package com.iititm.concretemonitor.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.google.android.glass.app.Card;
import com.google.android.glass.media.Sounds;
import com.google.android.glass.widget.CardScrollAdapter;
import com.google.android.glass.widget.CardScrollView;
import com.mongodb.*;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class RangeSensorData extends Activity {
    /**
     * Handler used to post requests to start new activities so that the menu closing animation
     * works properly.
     */
    private final Handler mHandler = new Handler();
    /** Audio manager used to play system sound effects. */
    private AudioManager mAudioManager;
    private List<Card> mCards;
    private CardScrollView mCardScrollView;

    /** Listener that displays the options menu when the card scroller is tapped. */
    private final AdapterView.OnItemClickListener mOnClickListener =
            new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                    mAudioManager.playSoundEffect(Sounds.TAP);
                    openOptionsMenu();
                }
            };


    /*methods */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        new DatabaseConnector().execute();
        //createCards();
    }

    private void createCards() {
        mCards = new ArrayList<Card>();

        Card card;

        card = new Card(this);
        card.setText("Sensor 2\nAbove 90 F");
        card.setFootnote("12:20 PM");
        mCards.add(card);

        card = new Card(this);
        card.setText("Sensor 4\nBelow 70 F");
        card.setFootnote("3:14 AM");
        mCards.add(card);
    }

    private class Range_Sensor_Data_Cardscroll_Adapter extends CardScrollAdapter {

        @Override
        public int getPosition(Object item) {
            return mCards.indexOf(item);
        }

        @Override
        public int getCount() {
            return mCards.size();
        }

        @Override
        public Object getItem(int position) {
            return mCards.get(position);
        }

        /**
         * Returns the amount of view types.
         */
        @Override
        public int getViewTypeCount() {
            return Card.getViewTypeCount();
        }

        /**
         * Returns the view type of this card so the system can figure out
         * if it can be recycled.
         */
        @Override
        public int getItemViewType(int position){
            return mCards.get(position).getItemViewType();
        }

        @Override
        public View getView(int position, View convertView,
                            ViewGroup parent) {
            return  mCards.get(position).getView(convertView, parent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.range_sensor_data, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // The startApp() method starts a new activity, and if we call it directly here then
        // the new activity will start without giving the menu a chance to slide back down first.
        // By posting the call to a handler instead, it will be processed on an upcoming pass
        // through the message queue, after the animation has completed, which results in a
        // smoother transition between activities.
        if (item.getItemId() == R.id.start_screen) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    startApp();
                }
            });
            return true;
        } else {
            return false;
        }
    }

    private void startApp() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private class DatabaseConnector extends AsyncTask<Void, Void, Void> {
        protected Void doInBackground(Void... params) {
            try{
                MongoClientURI uri  = new MongoClientURI("mongodb://processing:embedded@ds039717.mongolab.com:39717/embedded");
                MongoClient mongoClient = new MongoClient(uri);
                DB db = mongoClient.getDB(uri.getDatabase());
                DBCollection collection = db.getCollection("sensors");
                DBCursor cursor = collection.find();
                int counter = 0;
                try {
                    while(cursor.hasNext()){
                        JSONObject jObject = new JSONObject(cursor.next().toString());
                        Log.d("Item: ", jObject.toString());
                        DatabaseRecord databaseRecord = new DatabaseRecord(
                                jObject.getInt("sensor"),
                                jObject.getInt("value"),
                                jObject.getInt("time")
                        );
                        if (databaseRecord.value > 89)
                        {
                            Card card = new Card(getApplicationContext());
                            card.setText("Sensor: " + databaseRecord.sensor + "\nAbove 89 F");
                            card.setFootnote("" + databaseRecord.timestamp.toString());
                            mCards.add(card);
                            publishProgress();
                            counter++;
                        }
                        if (databaseRecord.value < 83)
                        {
                            Card card = new Card(getApplicationContext());
                            card.setText("Sensor: " + databaseRecord.sensor + "\nBelow 83 F");
                            card.setFootnote("" + databaseRecord.timestamp.toString());
                            mCards.add(card);
                            publishProgress();
                            counter++;
                        }
                        if (counter >= 20) {
                            cursor.close();
                        }
                    }
                } finally {
                    if (cursor.hasNext()) {
                    cursor.close();
                    }
                }
            } catch (Exception e) {
                Log.d("Something went wrong: ", e.toString());
            }
            return null;
        }

        protected void onPreExecute() {
            mCards = new ArrayList<Card>();
            mCardScrollView = new CardScrollView(getApplicationContext());
            Range_Sensor_Data_Cardscroll_Adapter adapter = new Range_Sensor_Data_Cardscroll_Adapter();
            mCardScrollView.setAdapter(adapter);
            mCardScrollView.activate();
            setContentView(mCardScrollView);
        }

        protected void onProgressUpdate() {
            mCardScrollView.activate();
            setContentView(mCardScrollView);
        }

        protected void onPostExecute() {
        }
    }
}
