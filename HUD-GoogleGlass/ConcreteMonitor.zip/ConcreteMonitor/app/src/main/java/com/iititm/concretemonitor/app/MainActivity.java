package com.iititm.concretemonitor.app;

import com.google.android.glass.media.Sounds;
import com.google.android.glass.touchpad.Gesture;
import com.google.android.glass.touchpad.GestureDetector;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Handler;
import android.view.MotionEvent;

// screen that displays the text concrete monitor and tap for options menu

public class MainActivity extends Activity {

    /** handler to post to that switches between activities */
     private final Handler mHandler = new Handler();

    /** Audio manager used to play system sound effects. */
    private AudioManager mAudioManager;

    /** Gesture detector used to present the options menu. */
    private GestureDetector mGestureDetector;

    /** Listener that displays the options menu when the touchpad is tapped. */
    private final GestureDetector.BaseListener mBaseListener = new GestureDetector.BaseListener() {
        @Override
        public boolean onGesture(Gesture gesture) {
            if (gesture == Gesture.TAP) {
                mAudioManager.playSoundEffect(Sounds.TAP);
                openOptionsMenu();
                return true;
            } else {
                return false;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        mGestureDetector = new GestureDetector(this).setBaseListener(mBaseListener);
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent event) {
        return mGestureDetector.onMotionEvent(event);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.start_concrete_monitor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // The startXXX() methods start a new activity, and if we call them directly here then
        // the new activity will start without giving the menu a chance to slide back down first.
        // By posting the calls to a handler instead, they will be processed on an upcoming pass
        // through the message queue, after the animation has completed, which results in a
        // smoother transition between activities.
        switch (item.getItemId()) {

            case R.id.all_sensor_data:
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        startAllSensorData();
                    }
                });
                return true;

            case R.id.current_sensor_data:
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        startCurrentSensorData();
                    }
                });
                return true;

            case R.id.range_sensor_data:
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        startRangeSensorData();
                    }
                });
                return true;

            default:
                return false;
        }
    }

    private void startCurrentSensorData() {
        startActivity(new Intent(this, CurrentSensorData.class));
    }

    private void startRangeSensorData() {
        startActivity(new Intent(this, RangeSensorData.class));
    }

    private void startAllSensorData() {
        startActivity(new Intent(this, AllSensorData.class));
    }


}





