package com.iititm.concretemonitor.app;

import java.util.Date;

public class DatabaseRecord {
    int sensor;
    int value;
    Date timestamp;
    public DatabaseRecord(int sensor, int value, Date timestamp) {
        this.sensor = sensor;
        this.value = value;
        this.timestamp = timestamp;
    }

    public DatabaseRecord(int sensor, int value, int epoch) {
        this.sensor = sensor;
        this.value = value;
        this.timestamp = new Date((long)epoch*1000);
    }
}
