package com.iititm.concretemonitor.app;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.mongodb.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class DatabaseConnector extends AsyncTask<Context, Void, ArrayList> {
    protected Context context;
    protected ArrayList doInBackground(Context... params) {
        this.context = params[0];
        ArrayList arrayList = new ArrayList();
        try{
            Log.d("Context: ", this.context.toString());
            MongoClientURI uri  = new MongoClientURI("mongodb://processing:embedded@ds039717.mongolab.com:39717/embedded");
            MongoClient mongoClient = new MongoClient(uri);
            DB db = mongoClient.getDB(uri.getDatabase());
            DBCollection collection = db.getCollection("sensors");
            DBCursor cursor = collection.find();
            try {
                while(cursor.hasNext()){
                    JSONObject jObject = new JSONObject(cursor.next().toString());
                    Log.d("Item: ", jObject.toString());
                    DatabaseRecord databaseRecord = new DatabaseRecord(
                            jObject.getInt("sensor"),
                            jObject.getInt("value"),
                            jObject.getInt("time")
                    );
                    arrayList.add(databaseRecord);
                }
            } finally {
                cursor.close();
            }
        } catch (Exception e) {
            Log.d("Something went wrong: ", e.toString());
        }
        return arrayList;
    }

    protected void onPostExecute(ArrayList result) {

    }
}

